import 'package:flutter/material.dart';
import '../presentation/m_notifikasi_container_screen/m_notifikasi_container_screen.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String mNotifikasiPage = '/m_notifikasi_page';

  static const String mNotifikasiContainerScreen =
      '/m_notifikasi_container_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    mNotifikasiContainerScreen: (context) => MNotifikasiContainerScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
