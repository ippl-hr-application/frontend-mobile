import 'widgets/list_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:muhammad_s__notifikasi/core/app_export.dart';

// ignore_for_file: must_be_immutable
class MNotifikasiPage extends StatelessWidget {
  const MNotifikasiPage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.base,
          child: Column(
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgRectangle17Copy,
                height: 16.v,
                width: 375.h,
                alignment: Alignment.centerLeft,
              ),
              SizedBox(height: 41.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 26.h),
                  child: Text(
                    "Notifikasi",
                    style: theme.textTheme.headlineSmall,
                  ),
                ),
              ),
              SizedBox(height: 16.v),
              _buildNotif(context),
              SizedBox(height: 15.v),
              _buildList(context),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildNotif(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.only(
          left: 23.h,
          right: 48.h,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgMaterialSymbol,
              height: 24.adaptSize,
              width: 24.adaptSize,
              margin: EdgeInsets.only(bottom: 32.v),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.only(left: 16.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Promosi",
                          style: theme.textTheme.bodySmall,
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 2.v),
                          child: Text(
                            "2 Maret, 12:00",
                            style: CustomTextStyles.labelMediumBluegray400,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8.v),
                    Text(
                      "Dapatkan Potongan 50% selama Bulan Maret!",
                      style: CustomTextStyles.labelMediumBlack900,
                    ),
                    SizedBox(height: 5.v),
                    Text(
                      "Syarat dan Ketentuan berlaku!",
                      style: CustomTextStyles.bodySmallBluegray400,
                    ),
                  ],
                ),
              ),
            ),
            Container(
              height: 8.adaptSize,
              width: 8.adaptSize,
              margin: EdgeInsets.only(
                left: 8.h,
                top: 6.v,
                bottom: 42.v,
              ),
              decoration: BoxDecoration(
                color: appTheme.green400,
                borderRadius: BorderRadius.circular(
                  4.h,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildList(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 23.h),
        child: ListView.separated(
          physics: BouncingScrollPhysics(),
          shrinkWrap: true,
          separatorBuilder: (
            context,
            index,
          ) {
            return Padding(
              padding: EdgeInsets.symmetric(vertical: 0.5.v),
              child: SizedBox(
                width: 328.h,
                child: Divider(
                  height: 1.v,
                  thickness: 1.v,
                  color: appTheme.gray300,
                ),
              ),
            );
          },
          itemCount: 1,
          itemBuilder: (context, index) {
            return ListItemWidget();
          },
        ),
      ),
    );
  }
}
