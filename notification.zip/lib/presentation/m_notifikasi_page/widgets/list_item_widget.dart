import 'package:flutter/material.dart';
import 'package:muhammad_s__notifikasi/core/app_export.dart';

// ignore: must_be_immutable
class ListItemWidget extends StatelessWidget {
  const ListItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CustomImageView(
          imagePath: ImageConstant.imgMaterialSymbol,
          height: 24.adaptSize,
          width: 24.adaptSize,
          margin: EdgeInsets.only(
            top: 17.v,
            bottom: 13.v,
          ),
        ),
        Padding(
          padding: EdgeInsets.only(
            left: 16.h,
            top: 17.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Notifikasi",
                style: theme.textTheme.bodySmall,
              ),
              SizedBox(height: 7.v),
              Text(
                "Password berhasil diubah",
                style: CustomTextStyles.labelMediumBlack900,
              ),
            ],
          ),
        ),
        Spacer(),
        Padding(
          padding: EdgeInsets.only(
            top: 21.v,
            bottom: 19.v,
          ),
          child: Text(
            "1 Maret, 10:00",
            style: CustomTextStyles.labelMediumBluegray400,
          ),
        ),
        Container(
          height: 8.adaptSize,
          width: 8.adaptSize,
          margin: EdgeInsets.fromLTRB(8.h, 23.v, 24.h, 23.v),
          decoration: BoxDecoration(
            color: appTheme.pink500,
            borderRadius: BorderRadius.circular(
              4.h,
            ),
          ),
        ),
      ],
    );
  }
}
