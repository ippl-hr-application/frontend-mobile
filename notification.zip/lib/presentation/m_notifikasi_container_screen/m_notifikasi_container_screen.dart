import 'package:muhammad_s__notifikasi/presentation/m_notifikasi_page/m_notifikasi_page.dart';
import 'package:muhammad_s__notifikasi/widgets/custom_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:muhammad_s__notifikasi/core/app_export.dart';

// ignore_for_file: must_be_immutable
class MNotifikasiContainerScreen extends StatelessWidget {
  MNotifikasiContainerScreen({Key? key}) : super(key: key);

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Navigator(
                key: navigatorKey,
                initialRoute: AppRoutes.mNotifikasiPage,
                onGenerateRoute: (routeSetting) => PageRouteBuilder(
                    pageBuilder: (ctx, ani, ani1) =>
                        getCurrentPage(routeSetting.name!),
                    transitionDuration: Duration(seconds: 0))),
            bottomNavigationBar: _buildBottomBar(context)));
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));
    });
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Beranda:
        return "/";
      case BottomBarEnum.Notifikasi:
        return AppRoutes.mNotifikasiPage;
      case BottomBarEnum.Kelas:
        return "/";
      case BottomBarEnum.Kursus:
        return "/";
      case BottomBarEnum.Akun:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.mNotifikasiPage:
        return MNotifikasiPage();
      default:
        return DefaultWidget();
    }
  }
}
