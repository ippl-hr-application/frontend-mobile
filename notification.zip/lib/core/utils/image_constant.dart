class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Common images
  static String imgRectangle17Copy = '$imagePath/img_rectangle_17_copy.png';

  static String imgMaterialSymbol = '$imagePath/img_material_symbol.svg';

  static String imgNavBeranda = '$imagePath/img_nav_beranda.svg';

  static String imgNavNotifikasi = '$imagePath/img_nav_notifikasi.svg';

  static String imgNavKelas = '$imagePath/img_nav_kelas.svg';

  static String imgNavKursus = '$imagePath/img_nav_kursus.svg';

  static String imgNavAkun = '$imagePath/img_nav_akun.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
